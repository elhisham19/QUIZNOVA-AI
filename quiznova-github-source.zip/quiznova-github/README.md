# QuizNova AI Science Quest 1–6

A React + TypeScript + Vite starter for a primary Science misconception-correction game.

## Run locally
1. Install Node.js (LTS).
2. Open this folder in VS Code or a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

## Build and deploy to Netlify
- Push this project to a GitHub repository.
- In Netlify, choose **Add new site → Import an existing project** and select the repository.
- Build command: `npm run build`
- Publish directory: `dist`

## What works in this starter
- Student and teacher views.
- Year 1–6 navigation.
- Five-stage Year 1 sample mystery: Living and Non-living Things.
- Two-tier answer + reasoning diagnostic.
- Immediate explanatory feedback and retry/continue flow.
- XP, badges, local progress persistence.
- Pre-test and post-test.
- Teacher activity summary and CSV export.

## Curriculum data status — read before classroom use
The provided `Prompt AI.pdf` describes the intended platform and provides links to six DSKP documents, but it does not contain the full extracted DSKP standards. This repository therefore includes **one illustrative Year 1 sample mission only**. Years 2–6 are placeholders. The sample SK/SP labels are explicitly marked for teacher verification; do not treat them as verified official wording.

To expand:
1. Add each verified standard to `src/data/curriculum.ts`.
2. Create misconception records with evidence status (`research`, `teacher-reported`, or `potential`).
3. Map each learning standard to one or more games.
4. Add question and reasoning choices with scientifically accurate feedback.
5. Validate the content against the official DSKP and have a Science teacher review it.
6. Only then update the coverage status to `validated`.

## Data and privacy
Progress is stored in the browser's `localStorage` on the current device. This starter does not create accounts, sync pupil data, or send data to a server. Use anonymous pupil identifiers and follow school privacy requirements before collecting any real pupil information.

## Suggested next development modules
- Full DSKP database and searchable coverage matrix.
- More game mechanics (drag-and-drop, simulation, sequencing, virtual experiment).
- Bahasa Melayu translation.
- Teacher-managed class profiles and secure data storage.
- Print-friendly intervention worksheets.
- AI-assisted teacher authoring behind a secure server-side API (never expose API keys in frontend code).
