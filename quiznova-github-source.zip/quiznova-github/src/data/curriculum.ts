import type { Mission, Question } from '../types'

// IMPORTANT: This is a small demonstration dataset, not a complete DSKP extraction.
// Verify all standard codes and wording against the official DSKP before classroom use.
const livingThingsQuestions: Question[] = [
  {
    id: 'y1-living-q1', stage: 'Observe the clues',
    prompt: 'Which one is a living thing?',
    options: ['A stone 🪨', 'A kitten 🐱', 'A toy car 🚗', 'A pencil ✏️'],
    correctIndex: 1,
    reasoningOptions: ['It carries out life processes.', 'It can move when someone pushes it.', 'It looks interesting.', 'I am not sure yet.'],
    correctReasoningIndex: 0,
    explanation: 'A kitten is living. It grows, needs food and carries out life processes. A stone, toy car and pencil do not.',
    misconception: 'A thing is living only because it can move.',
    demonstration: 'Compare a kitten with a toy car. The car can move when pushed, but it does not grow or need food.',
    standardRef: 'Teacher verification required',
  },
  {
    id: 'y1-living-q2', stage: 'Find the misconception',
    prompt: 'A car moves along the road. Does that make it a living thing?',
    options: ['Yes, because it moves.', 'No. Movement alone does not make something living.', 'Yes, because it uses fuel.', 'I am not sure yet.'],
    correctIndex: 1,
    reasoningOptions: ['All movement means something is alive.', 'A car does not carry out life processes.', 'It is large.', 'I am not sure yet.'],
    correctReasoningIndex: 1,
    explanation: 'A car moves because its engine and wheels make it move. It does not grow or carry out biological life processes.',
    misconception: 'Anything that moves is alive.',
    demonstration: 'Roll a toy car, then observe a growing plant. Discuss the difference between movement and life processes.',
    standardRef: 'Teacher verification required',
  },
  {
    id: 'y1-living-q3', stage: 'Test your idea',
    prompt: 'A seed is not moving. Is it living?',
    options: ['No, because it is not moving.', 'Yes. A viable seed can germinate and grow.', 'No, because it is small.', 'Only when it is green.'],
    correctIndex: 1,
    reasoningOptions: ['A seed can germinate under suitable conditions.', 'Living things must always move from place to place.', 'Small things cannot be alive.', 'I am not sure yet.'],
    correctReasoningIndex: 0,
    explanation: 'A viable seed is living even when it is dormant. It can germinate when it has suitable conditions.',
    misconception: 'A living thing must always be visibly moving.',
    demonstration: 'Place suitable seeds on damp cotton and observe changes over several days.',
    standardRef: 'Teacher verification required',
  },
  {
    id: 'y1-living-q4', stage: 'Explain the evidence',
    prompt: 'Why is a plant a living thing?',
    options: ['It stays in one place.', 'It is green.', 'It grows and carries out life processes.', 'It does not make a sound.'],
    correctIndex: 2,
    reasoningOptions: ['Plants carry out life processes even though they do not walk.', 'Only animals are living.', 'Green colour always means living.', 'I am not sure yet.'],
    correctReasoningIndex: 0,
    explanation: 'Plants are living things. They grow and carry out life processes even though they do not walk around.',
    misconception: 'Plants are non-living because they cannot move from place to place.',
    demonstration: 'Observe a plant over time and record growth. Discuss how plants respond to their surroundings.',
    standardRef: 'Teacher verification required',
  },
  {
    id: 'y1-living-q5', stage: 'Solve the mystery',
    prompt: 'A robot dog can walk, bark and respond to a remote control. What is it?',
    options: ['A living animal.', 'A non-living object designed to act like an animal.', 'A plant.', 'A real dog because it moves.'],
    correctIndex: 1,
    reasoningOptions: ['It is programmed and does not grow or carry out biological life processes.', 'Anything that acts like an animal is alive.', 'It has a dog shape.', 'I am not sure yet.'],
    correctReasoningIndex: 0,
    explanation: 'A robot is made by people. It may imitate some actions, but it does not grow or carry out biological life processes.',
    misconception: 'Anything that behaves like an animal must be alive.',
    demonstration: 'Compare a robot dog with a real puppy. Both may move, but only the puppy grows and carries out life processes.',
    standardRef: 'Teacher verification required',
  },
]

export const missions: Mission[] = [
  {
    id: 'y1-living-nonliving', year: 1,
    topic: 'Living and Non-living Things', icon: '🌱',
    title: 'The Living or Not Mystery',
    sk: 'Sample SK reference — verify against official DSKP',
    sp: 'Sample SP reference — verify exact numbering and wording',
    validation: 'sample-needs-verification',
    questions: livingThingsQuestions,
  },
  ...[2, 3, 4, 5, 6].map((year): Mission => ({
    id: `y${year}-placeholder`, year,
    topic: 'Curriculum content awaiting extraction',
    icon: ['','🌱','🦋','🧪','⚡','🌍','🚀'][year],
    title: 'Mission awaiting DSKP mapping',
    sk: 'Not extracted',
    sp: 'Not extracted',
    validation: 'awaiting-dskp',
    questions: [],
  })),
]

export const themeNames = [
  'Inkuiri Dalam Sains',
  'Sains Hayat',
  'Sains Fizikal',
  'Sains Bahan',
  'Bumi dan Angkasa',
  'Teknologi dan Kehidupan Lestari',
]
