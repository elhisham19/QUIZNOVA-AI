import { Download, FileSpreadsheet, ShieldCheck } from 'lucide-react'
import type { ActivityRecord, Mission } from '../types'
import { patternLabel } from '../logic'

interface Props { missions: Mission[]; activities: ActivityRecord[]; tests: Record<string,number>; onExport:()=>void }
export default function TeacherDashboard({missions,activities,tests,onExport}:Props){
 const patterns=[...new Set(activities.map(a=>a.pattern))]
 return <div className="page">
  <div className="section-heading"><div><span className="eyebrow">TEACHER SPACE</span><h1>Learning insights</h1><p>Review mission activity and curriculum readiness on this device.</p></div><button className="primary" onClick={onExport}><Download size={17}/> Export CSV</button></div>
  <div className="notice"><ShieldCheck/> <span><b>Curriculum validation notice:</b> The provided development prompt is not the six complete DSKP documents. Only one sample Year 1 game is supplied here; other years are placeholders. Do not report full curriculum coverage until standards and games have been verified.</span></div>
  <div className="stats"><div className="stat"><b>{activities.length}</b><span>DIAGNOSTIC RESPONSES</span></div><div className="stat"><b>{missions.filter(m=>m.validation==='validated').length}</b><span>VERIFIED MISSIONS</span></div><div className="stat"><b>{tests.pre===undefined?'—':`${tests.pre}/3`}</b><span>PRE-TEST</span></div><div className="stat"><b>{tests.post===undefined?'—':`${tests.post}/3`}</b><span>POST-TEST</span></div></div>
  <section className="card"><h2>Curriculum coverage tracker</h2><div className="table-wrap"><table><thead><tr><th>Year</th><th>Topic</th><th>SK / SP</th><th>Game</th><th>Validation</th></tr></thead><tbody>{missions.map(m=><tr key={m.id}><td>Year {m.year}</td><td>{m.topic}</td><td>{m.sk}<br/>{m.sp}</td><td>{m.questions.length?'Sample game':'Not developed'}</td><td>{m.validation==='validated'?'Verified':m.validation==='sample-needs-verification'?'Needs teacher verification':'Awaiting DSKP'}</td></tr>)}</tbody></table></div></section>
  <section className="card"><h2>Diagnostic response patterns</h2><p className="muted">A single incorrect answer is not proof of a misconception. Review repeated reasoning patterns and use follow-up questions.</p>{patterns.length?patterns.map(p=><div className="pattern-row" key={p}><span>{patternLabel(p)}</span><b>{activities.filter(a=>a.pattern===p).length}</b></div>):<p className="muted">No pupil responses recorded yet.</p>}</section>
  <section className="card"><h2>Recent activity</h2><div className="table-wrap"><table><thead><tr><th>Mission</th><th>Answer</th><th>Reasoning pattern</th><th>Date</th></tr></thead><tbody>{activities.slice(-15).reverse().map(a=><tr key={a.id}><td>{a.missionTitle}</td><td>{a.answerCorrect?'Correct':'Incorrect'}</td><td>{patternLabel(a.pattern)}</td><td>{new Date(a.createdAt).toLocaleString()}</td></tr>)}</tbody></table></div></section>
  <div className="notice">Privacy: this prototype stores progress in localStorage on the current browser only. It does not sync across devices or provide secure multi-user teacher accounts.</div>
 </div>
}
