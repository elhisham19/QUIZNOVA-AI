import { motion } from 'framer-motion'
import { BookOpen, FlaskConical, GraduationCap, Sparkles } from 'lucide-react'
import type { Mission } from '../types'

interface Props {
  year: number
  onYearChange: (year: number) => void
  missions: Mission[]
  onStart: (mission: Mission) => void
  xp: number
  solved: number
  badges: string[]
}

export default function StudentDashboard({ year, onYearChange, missions, onStart, xp, solved, badges }: Props) {
  const current = missions.filter(m => m.year === year)
  return <div className="page">
    <section className="hero">
      <div><span className="eyebrow">THE SCIENCE MISCONCEPTION BUSTERS</span>
        <h1>Think like a scientist.<br/>Solve the mystery!</h1>
        <p>Explore science missions, test your ideas and discover why things happen. Every mistake is a clue that helps you learn.</p>
        <div className="hero-note"><Sparkles size={18}/> Be curious. Look for evidence. Try again.</div>
      </div><div className="hero-art">🧪🕵️</div>
    </section>
    <div className="stats">
      <div className="stat"><b>⭐ {xp}</b><span>SCIENCE XP</span></div>
      <div className="stat"><b>🧩 {solved}</b><span>MYSTERIES SOLVED</span></div>
      <div className="stat"><b>🏅 {badges.length}</b><span>BADGES EARNED</span></div>
      <div className="stat"><b>📚 {year}</b><span>SELECTED YEAR</span></div>
    </div>
    <div className="section-heading"><div><h2>Choose your science year</h2><p>Select a level to explore its missions.</p></div><GraduationCap/></div>
    <div className="years">{[1,2,3,4,5,6].map(y=><button key={y} onClick={()=>onYearChange(y)} className={`year ${year===y?'selected':''}`}><span>{['🌱','🦋','🧪','⚡','🌍','🚀'][y-1]}</span><b>Year {y}</b></button>)}</div>
    <div className="section-heading"><div><h2>Year {year} missions</h2><p>Choose a topic to begin your investigation.</p></div><BookOpen/></div>
    <div className="mission-grid">{current.map(m=><motion.article whileHover={{y:-4}} className="mission-card" key={m.id}>
      <div className="mission-icon">{m.icon}</div><span className="tag">{m.validation==='validated'?'DSKP verified':m.validation==='sample-needs-verification'?'Sample · verify':'In development'}</span>
      <h3>{m.topic}</h3><p>{m.title}</p>
      <small>{m.questions.length ? `${m.questions.length} mystery stages` : 'Curriculum data not yet added'}</small>
      <button className="primary full" disabled={!m.questions.length} onClick={()=>onStart(m)}>{m.questions.length?'Start mission':'Awaiting DSKP data'} →</button>
    </motion.article>)}</div>
    <div className="section-heading"><div><h2>Your detective kit</h2><p>Rewards celebrate effort and scientific thinking.</p></div><FlaskConical/></div>
    <div className="badge-row">{(badges.length?badges:['First Discovery','Reasoning Star','Science Detective']).map(b=><span className="reward" key={b}>🏅 {b}</span>)}</div>
  </div>
}
