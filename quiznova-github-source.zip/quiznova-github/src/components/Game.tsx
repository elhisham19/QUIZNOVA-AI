import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, CheckCircle2, Lightbulb, RotateCcw } from 'lucide-react'
import type { Mission, Question, ReasoningPattern } from '../types'
import { classifyResponse, patternLabel } from '../logic'

interface Props { mission: Mission; onExit: () => void; onRecord: (q: Question, answerCorrect: boolean, reasoningCorrect: boolean, pattern: ReasoningPattern, completed: boolean) => void }
export default function Game({ mission, onExit, onRecord }: Props) {
  const [index,setIndex]=useState(0)
  const [answer,setAnswer]=useState<number|null>(null)
  const [reason,setReason]=useState<number|null>(null)
  const [checked,setChecked]=useState(false)
  const [finished,setFinished]=useState(false)
  const q=mission.questions[index]
  if (finished) return <div className="page game-page"><button className="text-button" onClick={onExit}><ArrowLeft size={17}/> Dashboard</button><div className="result-card"><div className="celebrate">🏆</div><h1>Mystery solved!</h1><p>You investigated {mission.questions.length} clues. Remember: a scientific explanation should be supported by evidence.</p><button className="primary" onClick={onExit}>Back to missions</button></div></div>
  const isCorrect=answer===q.correctIndex
  const reasonCorrect=reason===q.correctReasoningIndex
  const uncertain=reason===q.reasoningOptions.length-1
  const pattern=classifyResponse(isCorrect,reasonCorrect,uncertain)
  function check(){if(answer===null||reason===null)return;setChecked(true);onRecord(q,isCorrect,reasonCorrect,pattern,index===mission.questions.length-1)}
  function next(){if(index===mission.questions.length-1){setFinished(true);return}setIndex(v=>v+1);setAnswer(null);setReason(null);setChecked(false)}
  return <div className="page game-page">
    <button className="text-button" onClick={onExit}><ArrowLeft size={17}/> Back to dashboard</button>
    <div className="game-heading"><div><span className="eyebrow">YEAR {mission.year} · SCIENCE MYSTERY</span><h1>{mission.title}</h1><p>{mission.topic}</p></div><div className="stage-count">CLUE {index+1} / {mission.questions.length}</div></div>
    <div className="stage-track">{mission.questions.map((_,i)=><i key={i} className={i<=index?'done':''}/>)}</div>
    <motion.section key={q.id} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} className="question-card">
      <div className="detective">🕵️‍♀️</div><span className="tag centered">{q.stage}</span><h2>{q.prompt}</h2>
      <p className="muted centered">Choose your answer, then tell us why. Your reasoning is an important clue!</p>
      <div className="answer-grid">{q.options.map((option,i)=><button key={option} disabled={checked} className={`answer-option ${answer===i?'chosen':''} ${checked&&i===q.correctIndex?'is-correct':''} ${checked&&answer===i&&!isCorrect?'is-wrong':''}`} onClick={()=>setAnswer(i)}>{option}</button>)}</div>
      <div className="reason-block"><h3>Why did you choose that answer?</h3><div className="reason-grid">{q.reasoningOptions.map((r,i)=><button key={r} disabled={checked} className={`reason-option ${reason===i?'chosen':''}`} onClick={()=>setReason(i)}>{r}</button>)}</div></div>
      {checked&&<div className={`feedback ${isCorrect&&reasonCorrect?'success':'support'}`}><b>{isCorrect&&reasonCorrect?'Excellent scientific thinking!':'Good effort — let’s examine the evidence.'}</b><p>{q.explanation}</p><p><b>Detective demonstration:</b> {q.demonstration}</p><p><b>Diagnostic signal:</b> {patternLabel(pattern)}. This is a prompt for further exploration, not a label for the pupil.</p><p><b>Possible misconception to investigate:</b> {q.misconception}</p></div>}
      <div className="game-actions">{checked?<button className="primary" onClick={next}>{index===mission.questions.length-1?'Finish mystery':'Next clue →'}</button>:<button className="primary" disabled={answer===null||reason===null} onClick={check}>Check my clues</button>}</div>
    </motion.section>
    <div className="teacher-note"><Lightbulb size={18}/> Teacher note: the sample standard reference is not verified. Confirm curriculum alignment before formal classroom assessment.</div>
  </div>
}
