import { useState } from 'react'
import type { Mission } from '../types'

interface Props { mission: Mission; onSave: (type:'pre'|'post',score:number)=>void; scores: Record<string,number> }
export default function Assessment({mission,onSave,scores}:Props){
 const [type,setType]=useState<'pre'|'post'|null>(null),[index,setIndex]=useState(0),[answers,setAnswers]=useState<number[]>([]),[done,setDone]=useState(false)
 const qs=mission.questions.slice(0,3)
 function begin(t:'pre'|'post'){setType(t);setIndex(0);setAnswers([]);setDone(false)}
 function answer(i:number){const next=[...answers,i];if(index<qs.length-1){setAnswers(next);setIndex(index+1)}else{const score=next.reduce((n,a,j)=>n+(a===qs[j].correctIndex?1:0),0);setAnswers(next);onSave(type!,score);setDone(true)}}
 return <div className="card assessment"><span className="eyebrow">LEARNING CHECK</span><h2>Pre-test and post-test</h2><p className="muted">Take the pre-test before the game and the post-test after the intervention. This short demo test uses three questions.</p>
 <div className="button-row"><button className="primary" onClick={()=>begin('pre')}>Start pre-test</button><button className="secondary" onClick={()=>begin('post')}>Start post-test</button></div>
 {type&&!done&&<div className="test-question"><small>{type.toUpperCase()} TEST · QUESTION {index+1} OF {qs.length}</small><h3>{qs[index].prompt}</h3><div className="answer-grid">{qs[index].options.map((o,i)=><button className="answer-option" key={o} onClick={()=>answer(i)}>{o}</button>)}</div></div>}
 {done&&<div className="feedback success"><b>{type==='pre'?'Pre-test':'Post-test'} completed</b><p>Score: {scores[type!] ?? 0} / {qs.length}</p><p>Use the score as one indicator only. A score change alone does not prove conceptual change.</p></div>}
 <p className="muted">Recorded scores: Pre-test {scores.pre===undefined?'—':`${scores.pre}/3`} · Post-test {scores.post===undefined?'—':`${scores.post}/3`}</p>
 </div>
}
