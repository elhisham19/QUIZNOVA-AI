import type { AppState } from './types'

const KEY = 'quiznova-science-quest-v1'
const initialState: AppState = { xp: 0, solvedMissions: [], badges: [], activities: [], tests: {} }

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? { ...initialState, ...JSON.parse(raw) } : initialState
  } catch {
    return initialState
  }
}

export function saveState(state: AppState): void {
  localStorage.setItem(KEY, JSON.stringify(state))
}
