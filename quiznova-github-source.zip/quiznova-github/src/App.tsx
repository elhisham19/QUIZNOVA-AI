import { useMemo, useState } from 'react'
import { BookOpen, ChartNoAxesCombined, Languages, Sparkles } from 'lucide-react'
import StudentDashboard from './components/StudentDashboard'
import TeacherDashboard from './components/TeacherDashboard'
import Game from './components/Game'
import Assessment from './components/Assessment'
import { missions } from './data/curriculum'
import { loadState, saveState } from './storage'
import type { ActivityRecord, Mission, Question, ReasoningPattern } from './types'

export default function App(){
 const [view,setView]=useState<'student'|'teacher'>('student')
 const [year,setYear]=useState(1)
 const [mission,setMission]=useState<Mission|null>(null)
 const [assessmentOpen,setAssessmentOpen]=useState(false)
 const [state,setState]=useState(loadState)
 const [showLanguageInfo,setShowLanguageInfo]=useState(false)
 const allMissions=useMemo(()=>missions,[ ])
 function update(next:typeof state){setState(next);saveState(next)}
 function record(q:Question,answerCorrect:boolean,reasoningCorrect:boolean,pattern:ReasoningPattern,completed:boolean){
  const activity:ActivityRecord={id:crypto.randomUUID(),missionTitle:mission?.title??'Science mission',questionId:q.id,answerCorrect,reasoningCorrect,pattern,createdAt:new Date().toISOString()}
  const badges=[...state.badges]
  if(answerCorrect&&!badges.includes('First Discovery'))badges.push('First Discovery')
  if(answerCorrect&&reasoningCorrect&&!badges.includes('Reasoning Star'))badges.push('Reasoning Star')
  if(completed&&!badges.includes('Science Detective'))badges.push('Science Detective')
  const solved=completed&&mission&&!state.solvedMissions.includes(mission.id)?[...state.solvedMissions,mission.id]:state.solvedMissions
  update({...state,xp:state.xp+(answerCorrect?10:4),badges,solvedMissions:solved,activities:[...state.activities,activity]})
 }
 function saveTest(type:'pre'|'post',score:number){update({...state,tests:{...state.tests,[type]:score}})}
 function exportCSV(){
  const rows=[['Mission','Question ID','Answer correct','Reasoning correct','Pattern','Date'],...state.activities.map(a=>[a.missionTitle,a.questionId,String(a.answerCorrect),String(a.reasoningCorrect),a.pattern,a.createdAt])]
  const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n')
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='quiznova-diagnostic-report.csv';a.click();URL.revokeObjectURL(url)
 }
 return <div className="app-shell">
  <header className="topbar"><div className="brand"><div className="brand-icon">🕵️</div><div><b>QUIZNOVA AI</b><small>SCIENCE QUEST 1–6</small></div></div>
   <nav><button className={view==='student'?'nav-active':''} onClick={()=>{setView('student');setMission(null);setAssessmentOpen(false)}}><BookOpen size={16}/> Student</button><button className={view==='teacher'?'nav-active':''} onClick={()=>{setView('teacher');setMission(null)}}><ChartNoAxesCombined size={16}/> Teacher</button><button onClick={()=>setShowLanguageInfo(v=>!v)}><Languages size={16}/> BM / EN</button></nav>
  </header>
  {showLanguageInfo&&<div className="language-note"><Sparkles size={16}/> Bahasa Melayu translation module is planned. The current question bank is in English.</div>}
  {view==='teacher'?<TeacherDashboard missions={allMissions} activities={state.activities} tests={state.tests} onExport={exportCSV}/>:mission?<Game mission={mission} onExit={()=>setMission(null)} onRecord={record}/>:assessmentOpen?<div className="page"><button className="text-button" onClick={()=>setAssessmentOpen(false)}>← Back to dashboard</button><Assessment mission={missions[0]} onSave={saveTest} scores={state.tests}/></div>:<>
   <StudentDashboard year={year} onYearChange={setYear} missions={allMissions} onStart={setMission} xp={state.xp} solved={state.solvedMissions.length} badges={state.badges}/>
   <div className="page bottom-tools"><button className="secondary" onClick={()=>setAssessmentOpen(true)}>📝 Open pre-test / post-test</button></div>
  </>}
  <footer>QUIZNOVA AI SCIENCE QUEST 1–6 · Learn through curiosity, evidence and discovery.</footer>
 </div>
}
