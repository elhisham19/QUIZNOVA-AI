import type { ReasoningPattern } from './types'

export function classifyResponse(
  answerCorrect: boolean,
  reasoningCorrect: boolean,
  uncertain: boolean,
): ReasoningPattern {
  if (answerCorrect && reasoningCorrect) return 'scientific-understanding'
  if (answerCorrect) return 'incomplete-understanding'
  if (uncertain) return 'requires-exploration'
  return 'possible-misconception'
}

export function patternLabel(pattern: ReasoningPattern): string {
  const labels: Record<ReasoningPattern, string> = {
    'scientific-understanding': 'Scientific understanding',
    'incomplete-understanding': 'Possible incomplete understanding',
    'possible-misconception': 'Possible misconception — explore further',
    'requires-exploration': 'Requires further exploration',
  }
  return labels[pattern]
}
