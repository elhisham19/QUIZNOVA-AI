export type ReasoningPattern =
  | 'scientific-understanding'
  | 'incomplete-understanding'
  | 'possible-misconception'
  | 'requires-exploration'

export interface Question {
  id: string
  stage: string
  prompt: string
  options: string[]
  correctIndex: number
  reasoningOptions: string[]
  correctReasoningIndex: number
  explanation: string
  misconception: string
  demonstration: string
  standardRef: string
}

export interface Mission {
  id: string
  year: number
  topic: string
  icon: string
  title: string
  sk: string
  sp: string
  validation: 'sample-needs-verification' | 'awaiting-dskp' | 'validated'
  questions: Question[]
}

export interface ActivityRecord {
  id: string
  missionTitle: string
  questionId: string
  answerCorrect: boolean
  reasoningCorrect: boolean
  pattern: ReasoningPattern
  createdAt: string
}

export interface AppState {
  xp: number
  solvedMissions: string[]
  badges: string[]
  activities: ActivityRecord[]
  tests: Record<string, number>
}
